/********************************************************************************
 Written by: Vinod Desai, NEX Robotics Pvt. Ltd.
 Edited by: Sachitanand Malewar, NEX Robotics Pvt. Ltd.
 AVR Studio Version 4.17, Build 666

 Date: 26th December 2010

 Application example: Robot control over serial port via XBee wireless communication module 
 					  (located on the ATMEGA260 microcontroller adaptor board)

 Concepts covered:  serial communication
 
 Serial Port used: UART0

 There are two components to the motion control:
 1. Direction control using pins PORTA0 to PORTA3
 2. Velocity control by PWM on pins PL3 and PL4 using OC5A and OC5B.

 In this experiment for the simplicity PL3 and PL4 are kept at logic 1.
 
 Pins for PWM are kept at logic 1.
  
 Connection Details:  	
 						
  Motion control:		L-1---->PA0;		L-2---->PA1;
   						R-1---->PA2;		R-2---->PA3;
   						PL3 (OC5A) ----> Logic 1; 	PL4 (OC5B) ----> Logic 1; 


  Serial Communication:	PORTD 2 --> RXD1 UART1 receive for RS232 serial communication
						PORTD 3 --> TXD1 UART1 transmit for RS232 serial communication

						PORTH 0 --> RXD2 UART 2 receive for USB - RS232 communication
						PORTH 1 --> TXD2 UART 2 transmit for USB - RS232 communication

						PORTE 0 --> RXD0 UART0 receive for ZigBee wireless communication
						PORTE 1 --> TXD0 UART0 transmit for ZigBee wireless communication

						PORTJ 0 --> RXD3 UART3 receive available on microcontroller expansion socket
						PORTJ 1 --> TXD3 UART3 transmit available on microcontroller expansion socket

Serial communication baud rate: 9600bps
To control robot use number pad of the keyboard which is located on the right hand side of the keyboard.
Make sure that NUM lock is on.

Commands:
			Keyboard Key   ASCII value	Action
				8				0x38	Forward
				2				0x32	Backward
				4				0x34	Left
				6				0x36	Right
				5				0x35	Stop
				7				0x37	Buzzer on
				9				0x39	Buzzer off

 Note: 
 
 1. Make sure that in the configuration options following settings are 
 	done for proper operation of the code

 	Microcontroller: atmega2560
 	Frequency: 14745600
 	Optimization: -O0 (For more information read section: Selecting proper optimization 
 						options below figure 2.22 in the Software Manual)

 2. Difference between the codes for RS232 serial, USB and wireless communication is only in the serial port number.
 	Rest of the things are the same. 

 3. For USB communication check the Jumper 1 position on the ATMEGA2560 microcontroller adaptor board

 4. Auxiliary power can supply current up to 1 Ampere while Battery can supply current up to 
 	2 Ampere. When both motors of the robot changes direction suddenly without stopping, 
	it produces large current surge. When robot is powered by Auxiliary power which can supply
	only 1 Ampere of current, sudden direction change in both the motors will cause current 
	surge which can reset the microcontroller because of sudden fall in voltage. 
	It is a good practice to stop the motors for at least 0.5seconds before changing 
	the direction. This will also increase the useable time of the fully charged battery.
	the life of the motor.

*********************************************************************************/

/********************************************************************************

   Copyright (c) 2010, NEX Robotics Pvt. Ltd.                       -*- c -*-
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are met:

   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.

   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.

   * Neither the name of the copyright holders nor the names of
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

   * Source code can be used for academic purpose. 
	 For commercial use permission form the author needs to be taken.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE. 

  Software released under Creative Commence cc by-nc-sa licence.
  For legal information refer to: 
  http://creativecommons.org/licenses/by-nc-sa/3.0/legalcode

********************************************************************************/


#include<avr/io.h>
#include<avr/interrupt.h>
#include<util/delay.h>

unsigned char data; //to store received data from UDR1
unsigned long int ShaftCountLeft = 0; //to keep track of left position encoder 
unsigned long int ShaftCountRight = 0; //to keep track of right position encoder
unsigned int Degrees; //to accept angle in degrees for turning

#define RS 0
#define RW 1
#define EN 2
#define lcd_port PORTC

#define sbit(reg,bit)	reg |= (1<<bit)			// Macro defined for Setting a bit of any register.
#define cbit(reg,bit)	reg &= ~(1<<bit)		// Macro defined for Clearing a bit of any register.

//lcd function declarations
void init_ports();
void lcd_reset();
void lcd_init();
void lcd_wr_command(unsigned char);
void lcd_wr_char(char);
void lcd_line1();
void lcd_line2();
void lcd_string(char*);

unsigned int temp;
unsigned int unit;
unsigned int tens;
unsigned int hundred;
unsigned int thousand;
unsigned int million;

//Function to configure LCD port
void lcd_port_config (void)
{
 DDRC = DDRC | 0xF7; //all the LCD pin's direction set as output
 PORTC = PORTC & 0x80; // all the LCD pins are set to logic 0 except PORTC 7
}

void buzzer_pin_config (void)
{
 DDRC = DDRC | 0x08;		//Setting PORTC 3 as outpt
 PORTC = PORTC & 0xF7;		//Setting PORTC 3 logic low to turnoff buzzer
}

void motion_pin_config (void)
{
 DDRA = DDRA | 0x0F;
 PORTA = PORTA & 0xF0;
 DDRL = DDRL | 0x18;   //Setting PL3 and PL4 pins as output for PWM generation
 PORTL = PORTL | 0x18; //PL3 and PL4 pins are for velocity control using PWM.
}

//Function to configure INT4 (PORTE 4) pin as input for the left position encoder
void left_encoder_pin_config (void)
{
 DDRE  = DDRE & 0xEF;  //Set the direction of the PORTE 4 pin as input
 PORTE = PORTE | 0x10; //Enable internal pull-up for PORTE 4 pin
}

//Function to configure INT5 (PORTE 5) pin as input for the right position encoder
void right_encoder_pin_config (void)
{
 DDRE  = DDRE & 0xDF;  //Set the direction of the PORTE 4 pin as input
 PORTE = PORTE | 0x20; //Enable internal pull-up for PORTE 4 pin
}

//Configure PORTB 5 pin for servo motor 1 operation
void servo1_pin_config (void)
{
 DDRB  = DDRB | 0x20;  //making PORTB 5 pin output
 PORTB = PORTB | 0x20; //setting PORTB 5 pin to logic 1
}

//Configure PORTB 6 pin for servo motor 2 operation
void servo2_pin_config (void)
{
 DDRB  = DDRB | 0x40;  //making PORTB 6 pin output
 PORTB = PORTB | 0x40; //setting PORTB 6 pin to logic 1
}

//Configure PORTB 7 pin for servo motor 3 operation
void servo3_pin_config (void)
{
 DDRB  = DDRB | 0x80;  //making PORTB 7 pin output
 PORTB = PORTB | 0x80; //setting PORTB 7 pin to logic 1
}

//Function to Reset LCD
void lcd_set_4bit()
{
	_delay_ms(1);

	cbit(lcd_port,RS);				//RS=0 --- Command Input
	cbit(lcd_port,RW);				//RW=0 --- Writing to LCD
	lcd_port = 0x30;				//Sending 3
	sbit(lcd_port,EN);				//Set Enable Pin
	_delay_ms(5);					//Delay
	cbit(lcd_port,EN);				//Clear Enable Pin

	_delay_ms(1);

	cbit(lcd_port,RS);				//RS=0 --- Command Input
	cbit(lcd_port,RW);				//RW=0 --- Writing to LCD
	lcd_port = 0x30;				//Sending 3
	sbit(lcd_port,EN);				//Set Enable Pin
	_delay_ms(5);					//Delay
	cbit(lcd_port,EN);				//Clear Enable Pin

	_delay_ms(1);

	cbit(lcd_port,RS);				//RS=0 --- Command Input
	cbit(lcd_port,RW);				//RW=0 --- Writing to LCD
	lcd_port = 0x30;				//Sending 3
	sbit(lcd_port,EN);				//Set Enable Pin
	_delay_ms(5);					//Delay
	cbit(lcd_port,EN);				//Clear Enable Pin

	_delay_ms(1);

	cbit(lcd_port,RS);				//RS=0 --- Command Input
	cbit(lcd_port,RW);				//RW=0 --- Writing to LCD
	lcd_port = 0x20;				//Sending 2 to initialise LCD 4-bit mode
	sbit(lcd_port,EN);				//Set Enable Pin
	_delay_ms(1);					//Delay
	cbit(lcd_port,EN);				//Clear Enable Pin

	
}

//Function to Initialize LCD
void lcd_init()
{
	_delay_ms(1);

	lcd_wr_command(0x28);			//LCD 4-bit mode and 2 lines.
	lcd_wr_command(0x01);
	lcd_wr_command(0x06);
	lcd_wr_command(0x0E);
	lcd_wr_command(0x80);
		
}

	 
//Function to Write Command on LCD
void lcd_wr_command(unsigned char cmd)
{
	unsigned char temp;
	temp = cmd;
	temp = temp & 0xF0;
	lcd_port &= 0x0F;
	lcd_port |= temp;
	cbit(lcd_port,RS);
	cbit(lcd_port,RW);
	sbit(lcd_port,EN);
	_delay_ms(5);
	cbit(lcd_port,EN);
	
	cmd = cmd & 0x0F;
	cmd = cmd<<4;
	lcd_port &= 0x0F;
	lcd_port |= cmd;
	cbit(lcd_port,RS);
	cbit(lcd_port,RW);
	sbit(lcd_port,EN);
	_delay_ms(5);
	cbit(lcd_port,EN);
}

//Function to Write Data on LCD
void lcd_wr_char(char letter)
{
	char temp;
	temp = letter;
	temp = (temp & 0xF0);
	lcd_port &= 0x0F;
	lcd_port |= temp;
	sbit(lcd_port,RS);
	cbit(lcd_port,RW);
	sbit(lcd_port,EN);
	_delay_ms(5);
	cbit(lcd_port,EN);

	letter = letter & 0x0F;
	letter = letter<<4;
	lcd_port &= 0x0F;
	lcd_port |= letter;
	sbit(lcd_port,RS);
	cbit(lcd_port,RW);
	sbit(lcd_port,EN);
	_delay_ms(5);
	cbit(lcd_port,EN);
}


//Function to bring cursor at home position
void lcd_home()
{
	lcd_wr_command(0x80);
}


//Function to Print String on LCD
void lcd_string(char *str)
{
	while(*str != '\0')
	{
		lcd_wr_char(*str);
		str++;
	}
}

//Position the LCD cursor at "row", "column".

void lcd_cursor (char row, char column)
{
	switch (row) {
		case 1: lcd_wr_command (0x80 + column - 1); break;
		case 2: lcd_wr_command (0xc0 + column - 1); break;
		case 3: lcd_wr_command (0x94 + column - 1); break;
		case 4: lcd_wr_command (0xd4 + column - 1); break;
		default: break;
	}
}

//Function To Print Any input value upto the desired digit on LCD
void lcd_print (char row, char coloumn, unsigned int value, int digits)
{
	unsigned char flag=0;
	if(row==0||coloumn==0)
	{
		lcd_home();
	}
	else
	{
		lcd_cursor(row,coloumn);
	}
	if(digits==5 || flag==1)
	{
		million=value/10000+48;
		lcd_wr_char(million);
		flag=1;
	}
	if(digits==4 || flag==1)
	{
		temp = value/1000;
		thousand = temp%10 + 48;
		lcd_wr_char(thousand);
		flag=1;
	}
	if(digits==3 || flag==1)
	{
		temp = value/100;
		hundred = temp%10 + 48;
		lcd_wr_char(hundred);
		flag=1;
	}
	if(digits==2 || flag==1)
	{
		temp = value/10;
		tens = temp%10 + 48;
		lcd_wr_char(tens);
		flag=1;
	}
	if(digits==1 || flag==1)
	{
		unit = value%10 + 48;
		lcd_wr_char(unit);
	}
	if(digits>5)
	{
		lcd_wr_char('E');
	}
	
}

//Function to initialize ports
void port_init()
{
	motion_pin_config();
	buzzer_pin_config();
	left_encoder_pin_config(); //left encoder pin config
 	right_encoder_pin_config(); //right encoder pin config	
 	servo1_pin_config(); //Configure PORTB 5 pin for servo motor 1 operation
 	servo2_pin_config(); //Configure PORTB 6 pin for servo motor 2 operation 
 	servo3_pin_config(); //Configure PORTB 7 pin for servo motor 3 operation  
	lcd_port_config();
}

//TIMER1 initialization in 10 bit fast PWM mode  
//prescale:256
// WGM: 7) PWM 10bit fast, TOP=0x03FF
// actual value: 52.25Hz 
void timer1_init(void)
{
 TCCR1B = 0x00; //stop
 TCNT1H = 0xFC; //Counter high value to which OCR1xH value is to be compared with
 TCNT1L = 0x01;	//Counter low value to which OCR1xH value is to be compared with
 OCR1AH = 0x03;	//Output compare Register high value for servo 1
 OCR1AL = 0xFF;	//Output Compare Register low Value For servo 1
 OCR1BH = 0x03;	//Output compare Register high value for servo 2
 OCR1BL = 0xFF;	//Output Compare Register low Value For servo 2
 OCR1CH = 0x03;	//Output compare Register high value for servo 3
 OCR1CL = 0xFF;	//Output Compare Register low Value For servo 3
 ICR1H  = 0x03;	
 ICR1L  = 0xFF;
 TCCR1A = 0xAB; /*{COM1A1=1, COM1A0=0; COM1B1=1, COM1B0=0; COM1C1=1 COM1C0=0}
 					For Overriding normal port functionality to OCRnA outputs.
				  {WGM11=1, WGM10=1} Along With WGM12 in TCCR1B for Selecting FAST PWM Mode*/
 TCCR1C = 0x00;
 TCCR1B = 0x0C; //WGM12=1; CS12=1, CS11=0, CS10=0 (Prescaler=256)
}

// Timer 5 initialized in PWM mode for velocity control
// Prescale:256
// PWM 8bit fast, TOP=0x00FF
// Timer Frequency:225.000Hz
void timer5_init()
{
	TCCR5B = 0x00;	//Stop
	TCNT5H = 0xFF;	//Counter higher 8-bit value to which OCR5xH value is compared with
	TCNT5L = 0x01;	//Counter lower 8-bit value to which OCR5xH value is compared with
	OCR5AH = 0x00;	//Output compare register high value for Left Motor
	OCR5AL = 0xFF;	//Output compare register low value for Left Motor
	OCR5BH = 0x00;	//Output compare register high value for Right Motor
	OCR5BL = 0xFF;	//Output compare register low value for Right Motor
	OCR5CH = 0x00;	//Output compare register high value for Motor C1
	OCR5CL = 0xFF;	//Output compare register low value for Motor C1
	TCCR5A = 0xA9;	/*{COM5A1=1, COM5A0=0; COM5B1=1, COM5B0=0; COM5C1=1 COM5C0=0}
 					  For Overriding normal port functionality to OCRnA outputs.
				  	  {WGM51=0, WGM50=1} Along With WGM52 in TCCR5B for Selecting FAST PWM 8-bit Mode*/
	
	TCCR5B = 0x0B;	//WGM12=1; CS12=0, CS11=1, CS10=1 (Prescaler=64)
}

// Function for robot velocity control
void velocity (unsigned char left_motor, unsigned char right_motor)
{
	OCR5AL = (unsigned char)left_motor;
	OCR5BL = (unsigned char)right_motor;
}

void left_position_encoder_interrupt_init (void) //Interrupt 4 enable
{
 cli(); //Clears the global interrupt
 EICRB = EICRB | 0x02; // INT4 is set to trigger with falling edge
 EIMSK = EIMSK | 0x10; // Enable Interrupt INT4 for left position encoder
 sei();   // Enables the global interrupt 
}

void right_position_encoder_interrupt_init (void) //Interrupt 5 enable
{
 cli(); //Clears the global interrupt
 EICRB = EICRB | 0x08; // INT5 is set to trigger with falling edge
 EIMSK = EIMSK | 0x20; // Enable Interrupt INT5 for right position encoder
 sei();   // Enables the global interrupt 
}

//ISR for right position encoder
ISR(INT5_vect)  
{
 ShaftCountRight++;  //increment right shaft position count
 //UDR0 = ShaftCountRight;
}


//ISR for left position encoder
ISR(INT4_vect)
{
 ShaftCountLeft++;  //increment left shaft position count
 //UDR0 = ShaftCountLeft;
}

//Function used for setting motor's direction
void motion_set (unsigned char Direction)
{
 unsigned char PortARestore = 0;

 Direction &= 0x0F; 		// removing upper nibbel for the protection
 PortARestore = PORTA; 		// reading the PORTA original status
 PortARestore &= 0xF0; 		// making lower direction nibbel to 0
 PortARestore |= Direction; // adding lower nibbel for forward command and restoring the PORTA status
 PORTA = PortARestore; 		// executing the command
}

void forward (void) //both wheels forward
{
  motion_set(0x06);
}

void back (void) //both wheels backward
{
  motion_set(0x09);
}

void left (void) //Left wheel backward, Right wheel forward
{
  motion_set(0x05);
}

void right (void) //Left wheel forward, Right wheel backward
{
  motion_set(0x0A);
}

void soft_left (void) //Left wheel stationary, Right wheel forward
{
 motion_set(0x04);
}

void soft_right (void) //Left wheel forward, Right wheel is stationary
{
 motion_set(0x02);
}

void soft_left_2 (void) //Left wheel backward, right wheel stationary
{
 motion_set(0x01);
}

void soft_right_2 (void) //Left wheel stationary, Right wheel backward
{
 motion_set(0x08);
}

void stop (void)
{
  motion_set(0x00);
}


//Function used for turning robot by specified degrees
void angle_rotate(unsigned int Degrees)
{
 float ReqdShaftCount = 0;
 unsigned long int ReqdShaftCountInt = 0;

 ReqdShaftCount = (float) Degrees/ 4.090; // division by resolution to get shaft count
 ReqdShaftCountInt = (unsigned int) ReqdShaftCount;
 ShaftCountRight = 0; 
 ShaftCountLeft = 0; 

 while (1)
 {
  if((ShaftCountRight >= ReqdShaftCountInt) | (ShaftCountLeft >= ReqdShaftCountInt))
  break;
 }
 stop(); //Stop robot
}

//Function used for moving robot forward by specified distance

void linear_distance_mm(unsigned int DistanceInMM)
{
 float ReqdShaftCount = 0;
 unsigned long int ReqdShaftCountInt = 0;

 ReqdShaftCount = DistanceInMM / 5.338; // division by resolution to get shaft count
 ReqdShaftCountInt = (unsigned long int) ReqdShaftCount;
  
 ShaftCountRight = 0;
 while(1)
 {
  UDR0= ShaftCountRight;
  if(ShaftCountRight > ReqdShaftCountInt)
  {
  	break;
  }
 } 
 stop(); //Stop robot
}

void forward_mm(unsigned int DistanceInMM)
{
 forward();
 linear_distance_mm(DistanceInMM);
}

void back_mm(unsigned int DistanceInMM)
{
 back();
 linear_distance_mm(DistanceInMM);
}

void left_degrees(unsigned int Degrees) 
{
// 88 pulses for 360 degrees rotation 4.090 degrees per count
 left(); //Turn left
 angle_rotate(Degrees);
}



void right_degrees(unsigned int Degrees)
{
// 88 pulses for 360 degrees rotation 4.090 degrees per count
 right(); //Turn right
 angle_rotate(Degrees);
}


void soft_left_degrees(unsigned int Degrees)
{
 // 176 pulses for 360 degrees rotation 2.045 degrees per count
 soft_left(); //Turn soft left
 Degrees=Degrees*2;
 angle_rotate(Degrees);
}

void soft_right_degrees(unsigned int Degrees)
{
 // 176 pulses for 360 degrees rotation 2.045 degrees per count
 soft_right();  //Turn soft right
 Degrees=Degrees*2;
 angle_rotate(Degrees);
}

void soft_left_2_degrees(unsigned int Degrees)
{
 // 176 pulses for 360 degrees rotation 2.045 degrees per count
 soft_left_2(); //Turn reverse soft left
 Degrees=Degrees*2;
 angle_rotate(Degrees);
}

void soft_right_2_degrees(unsigned int Degrees)
{
 // 176 pulses for 360 degrees rotation 2.045 degrees per count
 soft_right_2();  //Turn reverse soft right
 Degrees=Degrees*2;
 angle_rotate(Degrees);
}

void buzzer_on (void)
{
 unsigned char port_restore = 0;
 port_restore = PINC;
 port_restore = port_restore | 0x08;
 PORTC = port_restore;
}

void buzzer_off (void)
{
 unsigned char port_restore = 0;
 port_restore = PINC;
 port_restore = port_restore & 0xF7;
 PORTC = port_restore;
}

//Function To Initialize UART0
// desired baud rate:9600
// actual baud rate:9600 (error 0.0%)
// char size: 8 bit
// parity: Disabled
void uart0_init(void)
{
 UCSR0B = 0x00; //disable while setting baud rate
 UCSR0A = 0x00;
 UCSR0C = 0x06;
 UBRR0L = 0x5F; //set baud rate lo
 UBRR0H = 0x00; //set baud rate hi
 UCSR0B = 0x98;
}

//Function To Initialize all The Devices
void init_devices()
{
 cli(); //Clears the global interrupts
 port_init();  //Initializes all the ports
 uart0_init(); //Initailize UART1 for serial communiaction
 timer1_init();
 timer5_init();
 left_position_encoder_interrupt_init();
 right_position_encoder_interrupt_init();
 sei();   //Enables the global interrupts
}

//Function to rotate Servo 1 by a specified angle in the multiples of 1.86 degrees
void servo_1(unsigned char degrees)  
{
 float PositionPanServo = 0;
 PositionPanServo = ((float)degrees / 1.86) + 35.0;
 OCR1AH = 0x00;
 OCR1AL = (unsigned char) PositionPanServo;
}

//Function to rotate Servo 2 by a specified angle in the multiples of 1.86 degrees
void servo_2(unsigned char degrees)
{
 float PositionTiltServo = 0;
 PositionTiltServo = ((float)degrees / 1.86) + 35.0;
 OCR1BH = 0x00;
 OCR1BL = (unsigned char) PositionTiltServo;
}

//Function to rotate Servo 3 by a specified angle in the multiples of 1.86 degrees
void servo_3(unsigned char degrees)
{
 float PositionServo = 0;
 PositionServo = ((float)degrees / 1.86) + 35.0;
 OCR1CH = 0x00;
 OCR1CL = (unsigned char) PositionServo;
}

//servo_free functions unlocks the servo motors from the any angle 
//and make them free by giving 100% duty cycle at the PWM. This function can be used to 
//reduce the power consumption of the motor if it is holding load against the gravity.

void servo_1_free (void) //makes servo 1 free rotating
{
 OCR1AH = 0x03; 
 OCR1AL = 0xFF; //Servo 1 off
}

void servo_2_free (void) //makes servo 2 free rotating
{
 OCR1BH = 0x03;
 OCR1BL = 0xFF; //Servo 2 off
}

void servo_3_free (void) //makes servo 3 free rotating
{
 OCR1CH = 0x03;
 OCR1CL = 0xFF; //Servo 3 off
} 

SIGNAL(SIG_USART0_RECV) 		// ISR for receive complete interrupt
{
	//data sent vis bluetooth
	//this is interrupt where data comes into code on bot
	//book id is sent via bluetooth to bot where it comes into UDR0
	//this is copied into global variable data and used in main
	data = UDR0; 				//making copy of data from UDR0 in 'data' variable 
	UDR0 = data; 				//echo data back to PC
}

//Main Function
int main(void)
{
	init_devices();
	velocity (200, 200); //Set robot velocity here. Smaller the value lesser will be the velocity
						 //Try different valuse between 0 to 255
	lcd_set_4bit();
	lcd_init();
	
	lcd_cursor(1,3);
	//lcd_string("FIRE BIRD 5");
	lcd_wr_char(data);
	
	//book id comes into variable data
	//based on id the bot has to go the correct location of book
	//each id is checked and then correct sequence of motions of bot to reach its location ar executed
	//then bot comes back to reference position
	//if any new request comes it will be stored in data and will executed next
	while(1){
	
		if(data == 0x30) //ASCII value of 0
		{
		//go to book location 1
			forward_mm(450);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(300);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(2500);
			forward_mm(50);
			stop();
			_delay_ms(2500);
			servo_1(0);
		  	_delay_ms(2500);
			servo_2(135);
		  	_delay_ms(2500);
			servo_1(75);
		  	_delay_ms(2500);
			servo_2(45);
		  	_delay_ms(2500);
			back_mm(50);
			stop();
			_delay_ms(2500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(300);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(450);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x31) //ASCII value of 1
		{
			//go to book location 2
			forward_mm(450);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(500);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(2500);
			forward_mm(50);
			stop();
			_delay_ms(2500);
			servo_1(0);
		  	_delay_ms(2500);
			servo_2(135);
		  	_delay_ms(2500);
			servo_1(75);
		  	_delay_ms(2500);
			servo_2(45);
		  	_delay_ms(2500);
			back_mm(50);
			stop();
			_delay_ms(2500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(500);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(450);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x32) //ASCII value of 2
		{
			//go to book location 3
			forward_mm(450);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(300);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(2500);
			forward_mm(50);
			stop();
			_delay_ms(2500);
			servo_1(0);
		  	_delay_ms(2500);
			servo_2(135);
		  	_delay_ms(2500);
			servo_1(75);
		  	_delay_ms(2500);
			servo_2(45);
		  	_delay_ms(2500);
			back_mm(50);
			stop();
			_delay_ms(2500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(300);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(450);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x33) //ASCII value of 3
		{
			//go to book location 4
			forward_mm(450);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(500);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(2500);
			forward_mm(50);
			stop();
			_delay_ms(2500);
			servo_1(0);
		  	_delay_ms(2500);
			servo_2(135);
		  	_delay_ms(2500);
			servo_1(75);
		  	_delay_ms(2500);
			servo_2(45);
		  	_delay_ms(2500);
			back_mm(50);
			stop();
			_delay_ms(2500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(500);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(450);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x34) //ASCII value of 4
		{
			//go to book location 5
			forward_mm(450);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(300);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(2500);
			servo_1(0);
		  	_delay_ms(2500);
			servo_2(135);
		  	_delay_ms(2500);
			forward_mm(50);
			stop();
			_delay_ms(2500);
			servo_2(45);
		  	_delay_ms(2500);
			servo_1(75);
		  	_delay_ms(2500);
			back_mm(50);
			stop();
			_delay_ms(2500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(300);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(450);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x35) //ASCII value of 5
		{
		//go to book location 6
			forward_mm(450);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(500);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(2500);
			servo_1(0);
		  	_delay_ms(2500);
			servo_2(135);
		  	_delay_ms(2500);
			forward_mm(50);
			stop();
			_delay_ms(2500);
			servo_2(45);
		  	_delay_ms(2500);
			servo_1(75);
		  	_delay_ms(2500);
			back_mm(50);
			stop();
			_delay_ms(2500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(500);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(450);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x36) //ASCII value of 6
		{
			//go to book location 7
			forward_mm(450);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(300);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(2500);
			servo_1(0);
		  	_delay_ms(2500);
			servo_2(135);
		  	_delay_ms(2500);
			forward_mm(50);
			stop();
			_delay_ms(2500);
			servo_2(45);
		  	_delay_ms(2500);
			servo_1(75);
		  	_delay_ms(2500);
			back_mm(50);
			stop();
			_delay_ms(2500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(300);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(450);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x37) //ASCII value of 7
		{
			//go to book location 8
			forward_mm(450);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(500);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(2500);
			servo_1(0);
		  	_delay_ms(2500);
			servo_2(135);
		  	_delay_ms(2500);
			forward_mm(50);
			stop();
			_delay_ms(2500);
			servo_2(45);
		  	_delay_ms(2500);
			servo_1(75);
		  	_delay_ms(2500);
			back_mm(50);
			stop();
			_delay_ms(2500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(500);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(450);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x38) //ASCII value of 8
		{
			//go to book location 1
			forward_mm(400);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(50);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			servo_1(0);
		  	_delay_ms(500);
			servo_2(90);
		  	_delay_ms(500);
			forward_mm(25);
			stop();
			_delay_ms(500);
			servo_2(45);
		  	_delay_ms(500);
			back_mm(25);
			stop();
			_delay_ms(500);
			servo_1(90);
		  	_delay_ms(500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(50);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(400);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x39) //ASCII value of 9
		{
			//go to book location 2
			forward_mm(400);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(100);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			servo_1(0);
		  	_delay_ms(500);
			servo_2(90);
		  	_delay_ms(500);
			forward_mm(25);
			stop();
			_delay_ms(500);
			servo_2(45);
		  	_delay_ms(500);
			back_mm(25);
			stop();
			_delay_ms(500);
			servo_1(90);
		  	_delay_ms(500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(100);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(400);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x41) //ASCII value of A
		{
			//go to book location 3
			forward_mm(400);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(150);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			servo_1(0);
		  	_delay_ms(500);
			servo_2(90);
		  	_delay_ms(500);
			forward_mm(25);
			stop();
			_delay_ms(500);
			servo_2(45);
		  	_delay_ms(500);
			back_mm(25);
			stop();
			_delay_ms(500);
			servo_1(90);
		  	_delay_ms(500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(150);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(400);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x42) //ASCII value of B
		{
			//go to book location 4
			forward_mm(400);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(200);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			servo_1(0);
		  	_delay_ms(500);
			servo_2(90);
		  	_delay_ms(500);
			forward_mm(25);
			stop();
			_delay_ms(500);
			servo_2(45);
		  	_delay_ms(500);
			back_mm(25);
			stop();
			_delay_ms(500);
			servo_1(90);
		  	_delay_ms(500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(200);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(400);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x43) //ASCII value of C
		{
			//go to book location 5
			forward_mm(400);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(50);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			servo_1(0);
		  	_delay_ms(500);
			servo_2(90);
		  	_delay_ms(500);
			forward_mm(25);
			stop();
			_delay_ms(500);
			servo_2(45);
		  	_delay_ms(500);
			back_mm(25);
			stop();
			_delay_ms(500);
			servo_1(90);
		  	_delay_ms(500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(50);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(400);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x44) //ASCII value of D
		{
		//go to book location 6
			forward_mm(400);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(100);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			servo_1(0);
		  	_delay_ms(500);
			servo_2(90);
		  	_delay_ms(500);
			forward_mm(25);
			stop();
			_delay_ms(500);
			servo_2(45);
		  	_delay_ms(500);
			back_mm(25);
			stop();
			_delay_ms(500);
			servo_1(90);
		  	_delay_ms(500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(100);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(400);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x45) //ASCII value of E
		{
			//go to book location 7
			forward_mm(400);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(150);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			servo_1(0);
		  	_delay_ms(500);
			servo_2(90);
		  	_delay_ms(500);
			forward_mm(25);
			stop();
			_delay_ms(500);
			servo_2(45);
		  	_delay_ms(500);
			back_mm(25);
			stop();
			_delay_ms(500);
			servo_1(90);
		  	_delay_ms(500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(150);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(400);
			stop();
			_delay_ms(500);
			data = 0x47;
		}
		
		if(data == 0x46) //ASCII value of F
		{
			//go to book location 8
			forward_mm(400);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			forward_mm(200);
			stop();
			_delay_ms(500);
			right_degrees(90);
			stop();
			_delay_ms(500);
			servo_1(0);
		  	_delay_ms(500);
			servo_2(90);
		  	_delay_ms(500);
			forward_mm(25);
			stop();
			_delay_ms(500);
			servo_2(45);
		  	_delay_ms(500);
			back_mm(25);
			stop();
			_delay_ms(500);
			servo_1(90);
		  	_delay_ms(500);
			servo_1_free();
			_delay_ms(500); 
		 	servo_2_free();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(200);
			stop();
			_delay_ms(500);
			left_degrees(90);
			stop();
			_delay_ms(500);
			back_mm(400);
			stop();
			_delay_ms(500);
			data = 0x47;
		}

		if(data == 0x47) //ASCII value of F
		{
		stop();
		}

	}
}

