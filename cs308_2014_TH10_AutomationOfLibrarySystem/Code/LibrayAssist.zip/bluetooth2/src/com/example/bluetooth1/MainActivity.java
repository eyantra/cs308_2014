//This is main file which is used for connection purpose.
package com.example.bluetooth1;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.*;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Set;
import java.util.UUID;


public class MainActivity extends ActionBarActivity {

    Button button,pick;
    Spinner spinner1;
    public Activity mainActivity = this;
    InputStream is = null;
    OutputStream os = null;
    BluetoothSocket bs = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addListenerOnButton();
        try {
            initBluetooth();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }
        // Inflate the menu; this adds items to the action bar if it is present.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        

        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
	      // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
    public boolean onOptionsItemSelected(MenuItem item) {
  
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void addListenerOnButton(){
        button = (Button) findViewById(R.id.scan_button1);
        pick = (Button) findViewById(R.id.scan_button);
        
        spinner1 = (Spinner) findViewById(R.id.spinner1);
        spinner1.setOnItemSelectedListener(new CustomOnItemSelectedListener());
        
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                IntentIntegrator integrator = new IntentIntegrator(mainActivity);
                integrator.initiateScan();
            }

        });
	//On clicking "Pick" button showing by message which book is picked and its ID	
        pick.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	
              String bookName = String.valueOf(spinner1.getSelectedItem());
              String toSend = "0";
              
              if(bookName.equalsIgnoreCase("Introduction to C++")){
              	toSend = "4";
              }
              else if(bookName.equalsIgnoreCase("Introduction to Java")){
              	toSend = "5";
              }
              else if(bookName.equalsIgnoreCase("Introduction to Python")){
                	toSend = "6";
                }
              else if(bookName.equalsIgnoreCase("Introduction to Html")){
                	toSend = "7";
                }
				try {
					sendData(toSend);
					Toast.makeText(getBaseContext(), "Book Name: " + bookName, Toast.LENGTH_SHORT).show();
		            Toast.makeText(getBaseContext(), "Book Id: " + toSend, Toast.LENGTH_SHORT).show();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
          });
    }
// Initiate scanning on clicking scan button
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
        if (scanResult != null) {
            TextView t = (TextView) findViewById(R.id.scan_format);
            String scanContent = "Scan Content: ";
            t.setText(scanContent + scanResult.getContents());
            try {
                sendBluetoothMessage(scanResult.getContents());
            } catch (IOException e) {}

        } else {
        }

    }
   //Initiate bluetooth connection between android phone and bluetooth module
    public void initBluetooth() throws IOException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            System.exit(1);
        }

        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1/*REQUEST_ENABLE_BT*/);
        }

        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {

            for (BluetoothDevice device : pairedDevices) {
                System.out.println(device.getAddress());
                if(device.getAddress().equals("00:19:A4:02:F0:F3")){
                    UUID uuid1 = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

                    Method m = device.getClass().getMethod("createRfcommSocket", new Class[] { int.class });
                    bs = (BluetoothSocket) m.invoke(device, 1);
                    mBluetoothAdapter.cancelDiscovery();
                }
            }
            
            
        }
        else
        {
        	
        }


    }
	//Placing book message to bot
    public void sendBluetoothMessage(String message) throws IOException {

        try {
            bs.connect();
        } catch (IOException connectException) {
            try {
                bs.close();
           } catch (IOException closeException) { }
        }
        os = bs.getOutputStream();
        os.write(message.getBytes());
    }
    //Send data to bot in order to retrieve book
    public void sendData(String message) throws IOException {
        try {

            bs.connect();
        } catch (IOException connectException) {
            try {
                bs.close();
           } catch (IOException closeException) { }
      //      return;
        }
        os = bs.getOutputStream();
        os.write(message.getBytes());*/
    }
    
}