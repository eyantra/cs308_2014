/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#include "type.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

// TODO: insert other include files here
#include "HardwareDefinition.h"
#include "FB6Lib.h"

// TODO: insert other definitions and declarations here
void InitPeripherals(void);
void Delay(void);
void Delay1s(void);
void Delay100ms(void);
void DelayRotate90(void);

/*===============================================================================
 Name        	 : InitPeripherals()
 Parameters		 : None
 Description 	 : This function initializes the peripherals of LPC1769 microcontroller
 	 	 	 	   and modules of Fire Bird VI robot as per the definitions in
 	 	 	 	   Hardwareprofile.h
 Preconditions	 : None
===============================================================================*/
void InitPeripherals(void)
{
	// delay to allow motor controller to initialize
	Delay100ms();
	UARTInit(2, 115200);
	InitMotorController();
	Stop();

	ResetI2C1();
	I2C1Init();

	// delay to allow LCD to initialize
	Delay1s();
	InitLCD();

}

/*===============================================================================
 Name        	 : Delay();
 Parameters		 : None
 Description 	 : Generates delay of very small amount
 Preconditions	 : None
===============================================================================*/
void Delay(void)
{
	uint32_t i=0;
	//for(i=0;i<10000;i++);
	for(i=0;i<100;i++);
}

/*===============================================================================
 Name        	 : Delay1s();
 Parameters		 : None
 Description 	 : Generates delay of approximately 1 Second
 Preconditions	 : None
===============================================================================*/
void Delay1s(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<110;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

void Delay2by3s(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<110;k++)
	{
		for(i=0;i<40000;i++)
		{
			j++;
		}
	}
}

//Calliberated function to delaying for time sufficient for FB-VI to move 1 inch [assuming speeds are (left = 35, right = 20)]
/*
The speeds of the two wheels (left and right) are set to
different values because the encoder is faulty.
Ideally, one should set the same speed for both
the wheels and re-calliberate.
*/
void Delay1inch(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<110;k++)
	{
		for(i=0;i<20833;i++)
		{
			j++;
		}
	}
}

//Calliberated function to delaying for time sufficient for FB-VI to move 't' inches [assuming speeds are (left = 35, right = 20)]
/*
The speeds of the two wheels (left and right) are set to
different values because the encoder is faulty.
Ideally, one should set the same speed for both
the wheels and re-calliberate.
*/
void Delaykinch(uint32_t t)
{
	while(t--)Delay1inch();
}

/*===============================================================================
 Name        	 : Delay100ms();
 Parameters		 : None
 Description 	 : Generates delay of approximately 100 milliseconds
 Preconditions	 : None
===============================================================================*/
void Delay100ms(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<11;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

void DelayRotate90(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<45;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

//Calliberated function to move FB-VI forward by 16 inches
void move16inch(){
	int j;
	for(j=0; j<5; j++){
		Move(35,20);
		Delay1s();
		Stop();
	}
	Stop();
}

//Calliberated function to move FB-VI forward by 't' inches
/*
The speeds of the two wheels (left and right) are set to
different values because the encoder is faulty.
Ideally, one should set the same speed for both
the wheels and re-calliberate.
*/
void movekinch(int t){
	int j;
	for(j=0; j<t; j++){
		Move(35,20);
		Delay1inch();
	}
	Stop();
}

//Calliberated function to rotate FB-VI by 90 degrees
void rotate90degree(){
	Move(-100,100); //Set the speed (left = -100, right = 100)
	int k;
	for(k=0; k<(90.0/8); k++){
		Delay1s();
	}
	Stop();
}

//Calliberated function to rotate FB-VI by -90 degrees
void rotateminus90degree(){
	Move(100,-100); //Set the speed (left = 100, right = -100)
	int k;
	for(k=0; k<(90.0/8); k++){
		Delay1s();
	}
	Stop();
}


void decode_and_execute(uint8_t instr){

	if(instr==0){
		return;
	}
	//Forward motion
	if(instr>>7 == 0){      //If the 1st bit (most significant bit) of the instruction is 0, then the instruction is to 'Move Forward'
		int dist = instr;   //The last 7 bits of the instruction represent the distance to be moved (in inches)
		int k = 0;
		movekinch(dist);    //Function to move 'dist' inches

	}
	//Rotation
	else if(instr>>7 == 1){   //If the 1st bit (most significant bit) of the instruction is 1, then the instruction is to 'Rotate'
		instr = instr & (~ (1 << 7)); //This gives the remaining 7 bits (i.e., the least significant bit to the 2nd most significant bit) of the instruction
		int dir = 1;
		if((instr & (1<<6))== (1<<6)) dir *= -1;    //The 2nd most significant bit of the instruction gives the sign of the angle of rotation. A '1' at this position means a negative angle. A '0' signifies that the angle is positive
		instr = instr & (~ (1 << 6));   //The last 6 bits of the instruction represents the magnitude of the angle to be turned (in degrees)
		int theta = instr;
		theta *= dir;
		if(dir>0) rotate90degree(); //Function to rotate 90 degrees
		else rotateminus90degree(); //Function to rotate -90 degrees
	}
}

int main(void) {
	SystemInit();			/*Inits PLL and Peripheral Clocks*/	//Core Clock(CCLK) = 120MHz, All Peripheral Clock = 1/4 * CCLK
	SystemClockUpdate();	/* SystemClockUpdate() updates the SystemFrequency variable */
	InitPeripherals();

	IRTrigger = 1;
	IRTriggerState = 0;
	WLTrigger = 1;
	WLTriggerState = 0;
	
	UARTInit(0,115200); //Initialize the UART: port=0, baud-rate = 115200
	
	while(1) {
		char instr = UART0Buffer[0];
	    if(instr == 0 ){
			continue;
		}
		uint8_t *BufferPtr = (uint8_t*)("S");
		UARTSend(0, BufferPtr, 1 );
		decode_and_execute(instr);
		uint8_t *BufferPtr1 = (uint8_t*)("U");
		UARTSend(0, BufferPtr1, 1 );
	}
	return 0 ;
}
