/*
===============================================================================
 Name        : main.c
 Author      :
 Version     :
 Copyright   : Copyright (C)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#include "type.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

#include <stdlib.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

// TODO: insert other include files here
#include "HardwareDefinition.h"
#include "FB6Lib.h"

uint32_t encCount=0;

// TODO: insert other definitions and declarations here
void InitPeripherals(void);
void Delay(void);
void Delay1s(void);
void Delay100ms(void);
void DelayRotate90(void);

/*===============================================================================
 Name        	 : InitPeripherals()
 Parameters		 : None
 Description 	 : This function initializes the peripherals of LPC1769 microcontroller
 	 	 	 	   and modules of Fire Bird VI robot as per the definitions in
 	 	 	 	   Hardwareprofile.h
 Preconditions	 : None
===============================================================================*/
void InitPeripherals(void)
{
	// delay to allow motor controller to initialize
	Delay100ms();
	UARTInit(2, 115200);
	InitMotorController();
	Stop();

	ResetI2C1();
	I2C1Init();

	// delay to allow LCD to initialize
	Delay1s();
	InitLCD();
}

/*===============================================================================
 Name        	 : Delay();
 Parameters		 : None
 Description 	 : Generates delay of very small amount
 Preconditions	 : None
===============================================================================*/
void Delay(void)
{
	uint32_t i=0;
	//for(i=0;i<10000;i++);
	for(i=0;i<100;i++);
}

/*===============================================================================
 Name        	 : Delay1s();
 Parameters		 : None
 Description 	 : Generates delay of approximately 1 Second
 Preconditions	 : None
===============================================================================*/
void Delay1s(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<110;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

/*===============================================================================
 Name        	 : Delay100ms();
 Parameters		 : None
 Description 	 : Generates delay of approximately 100 mili Second
 Preconditions	 : None
===============================================================================*/
void Delay100ms(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<11;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

void DelayRotate90(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<45;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

int main(void) {

	// TODO: insert code here
	SystemInit();			/*Inits PLL and Peripheral Clocks*/	//Core Clock(CCLK) = 120MHz, All Peripheral Clock = 1/4 * CCLK
	SystemClockUpdate();	/* SystemClockUpdate() updates the SystemFrequency variable */

	//Delay1s();
	InitPeripherals();
	Delay1s();

	LCDSetCursorPosition(1,1);
	LCD_WriteStr(20,(uint8_t *)"      FBRL DEMO     ");

	// set mode to position control
	SetMode(2);

	ClearEncoderCounts();
	SetAcceleration(10);
	DisableSafety();
	Delay1s();
	Delay1s();
	Delay1s();
	Delay1s();
	Delay1s();
	Delay1s();
	Delay1s();
	Delay1s();
	Delay1s();
	Delay1s();
	Delay1s();
	Delay1s();
	Delay1s();
	Delay1s();
	Delay1s();
	Delay1s();
	MoveForwardDistanceMM(10,254*10);
	//Stop();

	//MoveRotate(75,180);
	return 0 ;
}
