/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

/*
#include "lpc17xx.h"
#include "type.h"
#include "uart.h"
#include "HardwareDefinition.h"
#include "Hardwareprofile.h"
#include "i2c.h"
#include "adc.h"
#include "sensorboard.h"
#include "batterymonitor.h"
#include "motorcontroller.h"
#include "inertial.h"
#include "lcd.h"
#include "Gps.h"
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#include "type.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

// TODO: insert other include files here
#include "HardwareDefinition.h"
#include "Hardwareprofile.h"
#include "FB6Lib.h"


// TODO: insert other definitions and declarations here
/******************Global Variables****************************/

//volatile uint32_t UART0Status, UART1Status, UART2Status,  UART3Status;
volatile uint8_t UART0Buffer[UART_BUFSIZE], UART1Buffer[UART_BUFSIZE], UART2Buffer[UART_BUFSIZE], UART3Buffer[UART_BUFSIZE];
//volatile uint8_t Tx_Buffer[UART_BUFSIZE];
//volatile uint8_t Rx_Buffer[UART_BUFSIZE];
//volatile uint8_t UART2_RxBuffer[UART_BUFSIZE];

/**************************************************************/


/******************Function Prototypes****************************/
void InitLeds(void);
void InitSwitch(void);
void InitPeripherals(void);
void Delay(void);
void BlinkLEDs(void);
void Delay1s(void);
void Delay100ms(void);
void AcquireData(void);
void DelayRotate90(void);
/*****************************************************************/

/*===============================================================================
 Function        : InitLeds()
 Parameters		 : None
 Description 	 : Sets direction of LED IO pins
 Preconditions	 : Uncomment LED definition in Hardwareprofile.h
===============================================================================*/
void InitLeds(void)
{
	LPC_GPIO1->FIODIR&=	!(LED1 | LED2 | LED3 | LED4);
	LPC_GPIO1->FIODIR|= (LED1 | LED2 | LED3 | LED4);
}

/*===============================================================================
 Name        	 : InitSwitch()
 Parameters		 : None
 Description 	 : Sets direction of Switch IO pins
 Preconditions	 : Uncomment SWITCH definition in Hardwareprofile.h
===============================================================================*/
void InitSwitch(void)
{
	LPC_GPIO2->FIODIR&= !(SW1 | SW2 | SW3 | SW4);
}


/*===============================================================================
 Name        	 : InitPeripherals()
 Parameters		 : None
 Description 	 : This function initializes the peripherals of LPC1769 microcontroller
 	 	 	 	   and modules of Fire Bird VI robot as per the definitions in
 	 	 	 	   Hardwareprofile.h
 Preconditions	 : None
===============================================================================*/
void InitPeripherals(void)
{
#if (defined(MOTORCONTROLLER))
	// delay to allow motor controller to initialize
	Delay100ms();

	UARTInit(2, 115200);
	InitMotorController();
	Mode = 1;
	SetMode(Mode);
	Stop();
#endif

#ifdef LED
	InitLeds();
	BlinkLEDs();
#endif

#ifdef SWITCH
	InitSwitch();
#endif

#if (defined(POT) || defined(SERVOPOD))
	ADCInit(ADC_CLK);
	#if (defined(SERVOPOD))
	LPC_GPIO1->FIODIR|= P1_29;				//Set Direction of trigger pin
	UL_TRIG_OFF();							//Initially ServoPod Ultrasonic Trigger is set OFF
	#endif
#endif

#ifdef SENSORBOARD
	ResetI2C0();
	I2C0Init();
	I2CStop(0);

	#if (defined(WHITELINE))
	//Do Something
	#endif

	#if (defined(ULTRASONIC))
	//Do Something
	#endif

	#if (defined(IR_PROXIMITY))
	//Do Something
	#endif

	#if (defined(EXT_ADC))
	AD7998_WriteReg(AD7998_CONFIG,0x0FF8);		//Convert Channel 1, Filter On
	#endif
#endif

#if (defined(BATTERYMONITOR) || defined(INERTIAL) || defined(LCD))
	ResetI2C1();
	I2C1Init();
	I2CStop(1);

	#if (defined(BATTERYMONITOR))
		//Do Something
	#endif

	#if (defined(GYROSCOPE))
		Init_L3G4200D();
	#endif

	#if (defined(ACCELEROMETER))
		Init_LSM303DLHC_Accelerometer();
	#endif

	#if (defined(MAGNETOMETER))
		Init_LSM303DLHC_Magnetometer();
	#endif

	#if (defined(LCD))
		// delay to allow LCD to initialize
		Delay1s();
		InitLCD();
	#endif

#endif

#if (defined(BEAGLE))
	UARTInit(3, 115200);
#endif

#if (defined(GPS))
	UARTInit(0, 9600);
#endif

#if (defined(WIRELESS_COMMUNICATION))
	UARTInit(1,115200);
	#if (defined(BLUETOOTH))
	//Do Something
	#endif

	#if (defined(XBEE))
	//Do Something
	#endif

	#if (defined(WIFI))
	//Do Something
	#endif
#endif
}

/*===============================================================================
 Name        	 : Delay();
 Parameters		 : None
 Description 	 : Generates delay of very small amount
 Preconditions	 : None
===============================================================================*/
void Delay(void)
{
	uint32_t i=0;
	for(i=0;i<100;i++);
}

/*===============================================================================
 Name        	 : Delay1s();
 Parameters		 : None
 Description 	 : Generates delay of approximately 1 Second
 Preconditions	 : None
===============================================================================*/
void Delay1s(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<110;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

/*===============================================================================
 Name        	 : Delay100ms();
 Parameters		 : None
 Description 	 : Generates delay of approximately 100 milliseconds
 Preconditions	 : None
===============================================================================*/
void Delay100ms(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<11;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

void DelayRotate90(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<45;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

/*===============================================================================
 Name        	 : BlinkLEDs();
 Parameters		 : None
 Description 	 : This function blinks the LEDs on GPIO panel
 Preconditions	 : None
===============================================================================*/
void BlinkLEDs(void)
{
	LED1_ON();
	Delay100ms();
	LED1_OFF();
	LED2_ON();
	Delay100ms();
	LED2_OFF();
	LED3_ON();
	Delay100ms();
	LED3_OFF();
	LED4_ON();
	Delay100ms();
	LED4_OFF();
}


/*===============================================================================
 Name        	 : AcquireData();
 Parameters		 : None
 Description 	 : This function acquires data from sensor module, power management module, IMU
 	 	 	 	   and sets actuation signals for traction motors, servo motors, etc.
 Preconditions	 : None
===============================================================================*/
void AcquireData(void)
{
#ifdef BATTERYMONITOR
	Get_Battery_Status(Battery);			//Battery
#endif

#ifdef WHITELINE
	WLTriggerUpdate();
	Get_Whiteline_Data(Whiteline);			//Whiteline
#endif

#ifdef ULTRASONIC
	ULTriggerUpdate();
	Get_Ultrasonic_Data(Ultrasonic);		//Ultrasonic
#endif

#ifdef IR_PROXIMITY
	IRTriggerUpdate();
	Get_IR_Proximity_Data(IR_Proximity);	//IR_Proximity
#endif

#ifdef GYROSCOPE
	Get_XYZ_Rate(Gyroscope);				//Gyroscope
#endif

#ifdef ACCELEROMETER
	Get_XYZ_Acceleration(Accelerometer);	//Accelerometer
#endif

#ifdef MAGNETOMETER
	Get_XYZ_Magnetometer(Magnetometer);		//Magnetometer
#endif

#ifdef MOTORCONTROLLER
	AccelerationUpdate();
	MotorControl();
	if(ResetEncoderCounts==1)
	{
		ClearEncoderCounts();
		ResetEncoderCounts=0;
	}
	Left_Count_New_Locked=GetLeftMotorCount();
	Right_Count_New_Locked = GetRightMotorCount();
	if(UpdateMode == 1)
	{
		SetMode(Mode);
		Mode = GetMode();
		UpdateMode = 0;
	}
	if(UpdateSafety == 1)
	{
		if(Safety == 1)
			EnableSafety();
		else
			DisableSafety();
		UpdateSafety = 0;
	}
	if(updatePosition == 1)
	{
		SetPosition(positionLeft, velocityLeft, positionRight, velocityRight);
		updatePosition = 0;
	}
#endif

#ifdef POT
	PotValue = ADCRead(5);
#endif

#ifdef SERVOPOD
	ServoPOD_ADC = ADCRead(1);
	if(ServoUpdate==1)
	{
		if		(ServoType==PAN)	{UpdateServoPos(PanAngle,PAN);}
		else if (ServoType==TILT)	{UpdateServoPos(TiltAngle,TILT);}
		else if (ServoType==AUX)	{UpdateServoPos(AuxAngle,AUX);}
	}
#endif

#ifdef LED
	if(!SW1_PRESSED){LED1_ON();}
	else			{LED1_OFF();}
	if(!SW2_PRESSED){LED2_ON();	}
	else			{LED2_OFF();}
	if(!SW3_PRESSED){LED3_ON();}
	else			{LED3_OFF();}
	if(!SW4_PRESSED){LED4_ON();}
	else			{LED4_OFF();}
#endif

#ifdef EXT_ADC
	Get_AD7998_Data(AD7998ADC);
#endif
}

/******************Type Definitions in stdint.h file*************************

			typedef signed char int8_t;
			typedef unsigned char uint8_t;

			typedef short int16_t;
			typedef unsigned short uint16_t;

			typedef int int32_t;
			typedef unsigned int uint32_t;

****************************************************************************/

void decode_and_execute_old(uint8_t b0, uint8_t b1, uint8_t b2){
	if((char)b0 == 'F'){
		int x = b1*256 + b2;
		MoveForwardDistanceMM(100,x*10);

	} else if((char)b0 == 'R'){
		int theta = (int)b2;
		MoveRotate(25,theta);

	}
}

void decode_and_execute(uint8_t instr){

	//MoveForwardDistanceMM(100,10*2.54);
	//return;
	if(instr==0){
		/*
		 *
		 #ifdef LCD
			LCD_PrintData(2,10,123,3);
		#endif
		*/
		return;
	}
	if(instr>>7 == 0){
		int dist = instr;
		MoveForwardDistanceMM(100,dist*10*2.54);

	} else if(instr>>7 == 1){
		instr = instr & (~ (1 << 7));
		int dir = 1;
		if((instr & (1<<6))== (1<<6)) dir *= -1;
		instr = instr & (~ (1 << 6));
		int theta = instr;
		theta *= dir;
		MoveRotate(25,theta);
	}
}

int main(void) {
	
	// TODO: insert code here
	uint32_t Tick=0;


	SystemInit();			/*Inits PLL and Peripheral Clocks*/	//Core Clock(CCLK) = 120MHz, All Peripheral Clock = 1/4 * CCLK
	SystemClockUpdate();	/* SystemClockUpdate() updates the SystemFrequency variable */
	InitPeripherals();

	IRTrigger = 1;
	IRTriggerState = 0;
	WLTrigger = 1;
	WLTriggerState = 0;
	UARTInit(0,115200);

	SetMode(2);
	ClearEncoderCounts();
	SetAcceleration(10);
	DisableSafety();
	Delay1s();


	/*
	 *

	 #ifdef LCD

	InitLCD();
	LCDClearScreen();
		LCDSetCursorPosition(1,1);
		LCD_WriteStr(20,(uint8_t *)"Printing from PC");
		LCDSetCursorPosition(2,1);	LCD_WriteStr(3,(uint8_t *)"PC:");
	#endif
	*/

	// Enter an infinite loop
	while(1) {
		//AcquireData();
		//Volts = (float)Battery[0] * 0.0521 * 10.0;
		//Current = ((2.5 - ((float)Battery[1] * 0.0129)) / 0.185) * 100.0;
		//Temperature = ((float)Battery[2] * 1.29);
		//#ifdef LCD
		Tick++;
		if(Tick==Tick)
		{	//Delay1s();
			//UART3Buffer[0] = 65;
			//uint8_t *BufferPtr = (uint8_t*)("Hi");
			//UARTSend( 3, BufferPtr, 3 );
			//LCD_PrintData(2,10,UART3Buffer[0],3);
			decode_and_execute(UART0Buffer[0]);
			uint8_t *BufferPtr = (uint8_t*)("S");
			UARTSend(0, BufferPtr, 1 );
			//LCD_WriteStr(26,(uint8_t *)"Printing from PC again");
			//LCD_PrintData(3,18,Current,3);
			//LCD_PrintData(4,18,Temperature,3);
			//LCD_PrintData(2,11,Servo_Proximity,4);
			//LCD_PrintData(3,11,PotValue,4);
			Tick = 0;
		}
		//#endif

	}
	return 0 ;
}
