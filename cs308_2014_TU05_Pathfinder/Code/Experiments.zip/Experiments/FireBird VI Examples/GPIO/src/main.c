/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#include "type.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>
#include "uart.h"
#include "motorcontroller.h"

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

// TODO: insert other include files here
#include "HardwareDefinition.h"


// TODO: insert other definitions and declarations here
/******************Function Prototypes****************************/
void InitLeds(void);
void InitSwitch(void);
void InitPeripherals(void);
void Delay(void);
/*****************************************************************/

/*===============================================================================
 Function        : InitLeds()
 Parameters		 : None
 Description 	 : Sets direction of LED IO pins
 Preconditions	 : Uncomment LED definition in Hardwareprofile.h
===============================================================================*/
void InitLeds(void)
{
	LPC_GPIO1->FIODIR&=	!(LED1 | LED2 | LED3 | LED4);
	LPC_GPIO1->FIODIR|= (LED1 | LED2 | LED3 | LED4);
}

/*===============================================================================
 Name        	 : InitSwitch()
 Parameters		 : None
 Description 	 : Sets direction of Switch IO pins
 Preconditions	 : Uncomment SWITCH definition in Hardwareprofile.h
===============================================================================*/
void InitSwitch(void)
{
	LPC_GPIO2->FIODIR&= !(SW1 | SW2 | SW3 | SW4);
}

/*===============================================================================
 Name        	 : InitPeripherals()
 Parameters		 : None
 Description 	 : This function initializes the peripherals of LPC1769 microcontroller
 	 	 	 	   and modules of Fire Bird VI robot as per the definitions in
 	 	 	 	   Hardwareprofile.h
 Preconditions	 : None
===============================================================================*/
void InitPeripherals(void)
{
	int i = 0;
	// delay to allow motor controller to initialize
	for (i=0;i<1000;i++)
		Delay();
	UARTInit(2, 115200);
	InitMotorController();
	Stop();

	InitLeds();
	InitSwitch();
}

/*===============================================================================
 Name        	 : Delay();
 Parameters		 : None
 Description 	 : Generates delay of very small amount
 Preconditions	 : None
===============================================================================*/
void Delay(void)
{
	uint32_t i=0;
	for(i=0;i<100;i++);
}

int main(void) {
	
	// TODO: insert code here
	SystemInit();			/*Inits PLL and Peripheral Clocks*/	//Core Clock(CCLK) = 120MHz, All Peripheral Clock = 1/4 * CCLK
	SystemClockUpdate();	/* SystemClockUpdate() updates the SystemFrequency variable */
	InitPeripherals();

	// Enter an infinite loop
	while(1)
	{

		if(!SW1_PRESSED){LED1_ON();}
		else			{LED1_OFF();}
		if(!SW2_PRESSED){LED2_ON();	}
		else			{LED2_OFF();}
		if(!SW3_PRESSED){LED3_ON();}
		else			{LED3_OFF();}
		if(!SW4_PRESSED){LED4_ON();}
		else			{LED4_OFF();}

	}
	return 0 ;
}
