/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#include "type.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

// TODO: insert other include files here
#include "HardwareDefinition.h"
#include "Hardwareprofile.h"
#include "uart.h"
#include "i2c.h"
#include "lcd.h"
#include "motorcontroller.h"


// TODO: insert other definitions and declarations here

/******************Function Prototypes****************************/
void InitPeripherals(void);
void Delay(void);
void Delay1s(void);
/*****************************************************************/


/*===============================================================================
 Name        	 : InitPeripherals()
 Parameters		 : None
 Description 	 : This function initializes the peripherals of LPC1769 microcontroller
 	 	 	 	   and modules of Fire Bird VI robot as per the definitions in
 	 	 	 	   Hardwareprofile.h
 Preconditions	 : None
===============================================================================*/
void InitPeripherals(void)
{
#if (defined(MOTORCONTROLLER))
	int i=0;
	// delay to allow motor controller to initialize
	for (i=0;i<1000;i++)
		Delay();
	UARTInit(2, 115200);
	InitMotorController();
	Stop();
#endif
	ResetI2C1();
	I2C1Init();
	UARTInit(1,9600);
	Delay1s();
	InitLCD();
}

/*===============================================================================
 Name        	 : Delay();
 Parameters		 : None
 Description 	 : Generates delay of very small amount
 Preconditions	 : None
===============================================================================*/
void Delay(void)
{
	uint32_t i=0;
	//for(i=0;i<10000;i++);
	for(i=0;i<100;i++);
}

/*===============================================================================
 Name        	 : Delay1s();
 Parameters		 : None
 Description 	 : Generates delay of approximately 1 Second
 Preconditions	 : None
===============================================================================*/
void Delay1s(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<110;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

int main(void) {
	
	// TODO: insert code here
	SystemInit();			/*Inits PLL and Peripheral Clocks*/	//Core Clock(CCLK) = 120MHz, All Peripheral Clock = 1/4 * CCLK
	SystemClockUpdate();	/* SystemClockUpdate() updates the SystemFrequency variable */
	InitPeripherals();
	Delay1s();

	LCDSetCursorPosition(1,1);
	LCD_WriteStr(20,(uint8_t *)"     WIFI DEMO      ");

	// Enter an infinite loop
	while(1)
	{
		MotorControl();
	}
	return 0 ;
}
